<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       garidium.com
 * @since      1.0.0
 *
 * @package    G_ffl_Cockpit
 * @subpackage G_ffl_Cockpit/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
